/**
 * @author Ramon Silva
 */
public interface InterfaceTomada2Pinos {
}
