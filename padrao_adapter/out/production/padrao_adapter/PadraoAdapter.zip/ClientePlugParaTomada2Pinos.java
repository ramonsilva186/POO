import com.katyusco.padroes.adpater.servicos.Fio;
import com.katyusco.padroes.adpater.servicos.ServicoTomada3Pinos;

/**
 * @author Ramon Silva
 */

public class ClientePlugParaTomada2Pinos {

    private final Fio pinoFase;
    private final Fio pinoNeutro;

    public ClientePlugParaTomada2Pinos(Fio pinoFase, Fio pinoNeutro) {
        this.pinoFase = pinoFase;
        this.pinoNeutro = pinoNeutro;
    }

    private void acoplaPlug(){
        AdapterTomada adaptador = new AdapterTomada(this.pinoFase, this.pinoNeutro, null);
        ServicoTomada3Pinos tomada = new ServicoTomada3Pinos(adaptador.getFase(), adaptador.getNeutro(), adaptador.getTerra());
        tomada.forneceEnergia();
    }

    public static void main(String[] args) {
        ClientePlugParaTomada2Pinos plug2pinos = new ClientePlugParaTomada2Pinos(Fio.FASE, Fio.NEUTRO);
        plug2pinos.acoplaPlug();
    }
}
