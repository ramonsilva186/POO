import com.katyusco.padroes.adpater.servicos.Fio;
import com.katyusco.padroes.adpater.servicos.ServicoTomada3Pinos;

/**
 * @author Ramon Silva
 */

public class AdapterTomada extends ServicoTomada3Pinos {

    private final Fio fase;
    private final Fio neutro;
    private final Fio terra;

    public AdapterTomada(Fio fioVermelho, Fio fioAzulClaro, Fio fioVerdeAmarelo) {
        super(fioVermelho, fioAzulClaro, fioVerdeAmarelo);
        this.fase = fioVermelho;
        this.neutro = fioAzulClaro;
        this.terra = fioVerdeAmarelo;
    }

    public Fio getFase() {
        return fase;
    }

    public Fio getNeutro() {
        return neutro;
    }

    public Fio getTerra() {
        return terra;
    }
}
